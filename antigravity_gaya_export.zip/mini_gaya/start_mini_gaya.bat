@echo off
title Mini Gaya Desktop Companion
cd /d "%~dp0"
echo ==========================================================
echo   Mini Gaya Desktop Companion & Voice Suite
echo   Bodhi Core - Sacred Gold & Obsidian
echo ==========================================================
echo.

python -c "import PySide6" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [!] PySide6 not detected in default Python.
    echo [*] Checking portable Python environments...
    if exist "D:\Ai_Tools\ComfyUI_windows_portable\python_embeded\python.exe" (
        start "" "D:\Ai_Tools\ComfyUI_windows_portable\python_embeded\pythonw.exe" "%~dp0jarvis_sprite.py"
        exit /b 0
    )
    echo [*] Installing PySide6 via pip...
    pip install PySide6
)

start "" pythonw "%~dp0jarvis_sprite.py"
exit /b 0
