import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import os from "os";
import path from "path";

// Live JARVIS state from the v10 harness event log.
// Same rules as Desktop\JARVIS\sprite\jarvis_state.py (the desktop pet + status line).
// broken > hold > approved > spawning > thinking > idle > asleep

export const dynamic = "force-dynamic";

const J = path.join(os.homedir(), ".jarvis");

type Ev = { ts?: string; ev?: string; agent?: string; tool?: string; decision?: string; reason?: string; verdict?: string };

async function tail(file: string, bytes = 200_000): Promise<Ev[]> {
  try {
    const fh = await fs.open(file, "r");
    const { size } = await fh.stat();
    const start = Math.max(0, size - bytes);
    const buf = Buffer.alloc(size - start);
    await fh.read(buf, 0, buf.length, start);
    await fh.close();
    return buf
      .toString("utf8")
      .split(/\r?\n/)
      .slice(-400)
      .flatMap((l) => {
        try {
          return [JSON.parse(l) as Ev];
        } catch {
          return [];
        }
      });
  } catch {
    return [];
  }
}

export async function GET() {
  const now = Date.now();
  const age = (e: Ev) => (e.ts ? (now - new Date(e.ts).getTime()) / 1000 : 1e9);
  let status = "";
  try {
    status = (await fs.readFile(path.join(J, "STATUS"), "utf8")).trim();
  } catch {}
  const armed = status.split(" ")[0] || "?";
  const reply = (state: string, detail: string) => NextResponse.json({ state, detail, armed });

  try {
    await fs.access(path.join(J, "DISABLED"));
    return reply("broken", "guard disabled");
  } catch {}
  if (status.startsWith("BROKEN")) return reply("broken", status);

  const evs = await tail(path.join(J, "logs", "events.jsonl"));
  for (let i = evs.length - 1; i >= 0; i--) {
    const e = evs[i];
    const a = age(e);
    if (a > 600) break;
    if (e.ev === "guard" && a < 25) return reply("hold", `${e.decision}: ${(e.reason || "").slice(0, 60)}`);
    if (e.ev === "subagent_stop" && (e.agent === "logos" || e.agent === "edidth") && e.verdict === "PASS" && a < 15)
      return reply("approved", "LOGOS PASS");
  }
  const recent = evs.filter((e) => age(e) < 25);
  if (recent.some((e) => e.ev === "tool" && e.agent && e.agent !== "main")) return reply("spawning", "subagents working");
  if (recent.length) return reply("thinking", recent[recent.length - 1].tool || recent[recent.length - 1].ev || "");
  if (evs.length && age(evs[evs.length - 1]) < 600) return reply("idle", "standing by");
  return reply("asleep", "no session activity");
}
