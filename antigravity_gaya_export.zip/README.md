# ⚔️ Gaya Agent Suite (v10 Fused Edition)

[![Skills](https://img.shields.io/badge/Skills-76%20modules-a78bfa)](#-the-76-skills-armory)
[![Agents](https://img.shields.io/badge/Agents-Council%20of%205-34d399)](#-the-council-of-gaya)
[![Companion](https://img.shields.io/badge/Desktop-Mini%20Gaya-gold)](#-mini-gaya-desktop-companion)
[![Voice](https://img.shields.io/badge/Voice-Whisper%20%2B%20Kokoro-blue)](#-local-voice-pipeline)

The complete, autonomous AI operating system for Google Antigravity, featuring **Gaya** (Commander-in-Chief), the fused subagent council, **76 domain skills**, **Mini Gaya** desktop companion with local push-to-talk voice, and the **Council of Gaya** Next.js 14 operator dashboard.

---

## ⚡ Quick 1-Click Installation

### On Windows:
1. Extract this zip archive.
2. Double-click **`install.bat`** (or run `powershell -ExecutionPolicy Bypass -File .\install.ps1`).
3. Open or restart Antigravity.

### On macOS / Linux:
```bash
chmod +x install.sh
./install.sh
```

---

## 🏛️ The Council of Gaya

```
┌────────────────────────────────────────────────────────────────────────┐
│                        ⚔️ GAYA (Commander-in-Chief)                     │
│               Bodh Gaya · Niti 4 Pillars · Ponytail's Ladder           │
└───────────────────────────────────┬────────────────────────────────────┘
          ┌─────────────────────────┼─────────────────────────┐
          ▼                         ▼                         ▼
  🛡️ LOGOS (Mind)             🔨 Bob (Hands)           🎨 Freya (Heart)
  [LOGOS + EDIDTH]          [Bob + VERONICA]          [Freya + FRIDAY]
  • Mastermind Planner      • Precision Builder       • Jolly Polymath Designer
  • Mandatory 6-Step QC     • Atomic commits          • High-taste UI/UX & Decks
  • Strict PASS/FAIL gate   • Receipts over narrative • Uncensored deep research
  • Zero unverified writes  • Spec-gap escalation     • Multimodal / Vision
          │
          └─────────────────────────┬─────────────────────────┘
                                    ▼
                          🦾 Tvashtar (Craftsman & Toolkeeper)
                          [Tvashtar + DUM-E]
                          • Systems Architecture & Refactoring
                          • Specialty Pool Toolkeeper (12 domains)
                          • Fetches & hands off BIM, XR, AppSec, Houdini
```

---

## 🖥️ Mini Gaya: Desktop Companion & Voice (`mini_gaya/`)
- Double-click **`mini_gaya/start_mini_gaya.bat`** to launch the floating desktop widget.
- **Approval Cards**: `Allow / Always / Deny` cards for tool and command executions.
- **Morning Briefing**: Daily agenda, status hops, and notifications.
- **Local Voice**: Whisper STT (`small.en`) + Kokoro TTS for hands-free push-to-talk conversations.

---

## 🌐 Council of Gaya: Operator Dashboard (`council_of_gaya/`)
- Double-click **`council_of_gaya/start_council.bat`** to launch on `http://localhost:4200`.
- Real-time memory inspection, 5-agent live status grid, and 76-skill visual catalog.
