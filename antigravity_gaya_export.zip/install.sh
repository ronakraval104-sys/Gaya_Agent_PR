#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "   GAYA SUITE AUTO-INSTALLER FOR ANTIGRAVITY"
echo "=========================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${HOME}/.gemini/config"

if [ "$1" == "--workspace" ]; then
    TARGET_DIR="$(pwd)/.agents"
fi

mkdir -p "$TARGET_DIR/rules" "$TARGET_DIR/skills" "$TARGET_DIR/agents"

cp -R "$SCRIPT_DIR/config/rules/"* "$TARGET_DIR/rules/"
cp -R "$SCRIPT_DIR/config/agents/"* "$TARGET_DIR/agents/"
cp -R "$SCRIPT_DIR/config/skills/"* "$TARGET_DIR/skills/"
cp "$SCRIPT_DIR/config/mcp_config.json" "$TARGET_DIR/mcp_config.json"

echo "Installation complete! 76 skills and 5 agents active."
