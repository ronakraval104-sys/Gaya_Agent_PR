"""JARVIS desktop pet - the Command Core, floating, always on top, live.

Reads JARVIS's real state from ~/.jarvis/logs/events.jsonl every second
(see jarvis_state.py) and acts it out:
  idle      white breathing glow, slow float
  thinking  light sweeps across the visor
  spawning  core flares, four satellites orbit (the <=4 subagent wave)
  hold      amber - the guard asked/denied, waiting on Boss
  broken    red flicker - harness doctor BROKEN or guard disabled
  approved  green, chevrons light bottom -> top (EDIDTH PASS)
  asleep    lights banked, faint core

Drag to move. Double-click: size. Right-click: size / demo / quit.
"""
import json
import math
import os
import random
import sys
import time

from PIL import Image
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QAction, QColor, QImage, QPainter, QRadialGradient
from PySide6.QtWidgets import QApplication, QMenu, QWidget

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import jarvis_state  # noqa: E402

L = os.path.join(HERE, "layers")
PREFS = os.path.join(os.path.expanduser("~"), ".jarvis", "pet.json")
STATES = ["idle", "thinking", "spawning", "hold", "broken", "approved", "asleep"]
COLOR = {"idle": (235, 242, 255), "thinking": (200, 235, 255), "spawning": (200, 240, 255),
         "hold": (255, 176, 32), "broken": (255, 59, 59), "approved": (47, 211, 111),
         "asleep": (150, 170, 200)}
SIZES = {"S": 140, "M": 200, "L": 300}
# chevron rows in 512 space (y0, y1), bottom first
CHEV_ROWS = [(420, 450), (393, 422), (365, 395)]
VISOR = (95, 140, 418, 205)


def qimg(pil):
    pil = pil.convert("RGBA")
    data = pil.tobytes("raw", "RGBA")
    q = QImage(data, pil.width, pil.height, QImage.Format_RGBA8888)
    return q.copy()


def tinted(alpha_img, rgb, mask=None):
    a = alpha_img.getchannel("A")
    if mask is not None:
        from PIL import ImageChops
        a = ImageChops.multiply(a, mask)
    solid = Image.new("RGBA", alpha_img.size, rgb + (255,))
    solid.putalpha(a)
    return qimg(solid)


class Pet(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setToolTip("JARVIS")
        prefs = self.load_prefs()
        self.size_key = prefs.get("size", "M")
        self.demo = False
        self.state, self.detail = "idle", ""
        self.t0 = time.time()
        self.flick = 1.0

        base = Image.open(os.path.join(L, "base.png"))
        glow = Image.open(os.path.join(L, "glow.png"))
        bloom = Image.open(os.path.join(L, "bloom.png"))
        m_core = Image.open(os.path.join(L, "mask_core.png"))
        self.base = qimg(base)
        self.glow = {s: tinted(glow, c) for s, c in COLOR.items()}
        self.bloom = {s: tinted(bloom, c) for s, c in COLOR.items()}
        self.core = {s: tinted(glow, c, m_core) for s, c in COLOR.items()}
        self.white = tinted(glow, (255, 255, 255))

        self.apply_size()
        if "x" in prefs:
            self.move(prefs["x"], prefs["y"])
        else:
            g = QApplication.primaryScreen().availableGeometry()
            self.move(g.right() - self.width() - 24, g.bottom() - self.height() - 24)

        self.anim = QTimer(self, timeout=self.update)
        self.anim.start(33)
        self.poll = QTimer(self, timeout=self.read_state)
        self.poll.start(1000)
        self.read_state()
        self._drag = None

    # ---------------------------------------------------------------- state
    def read_state(self):
        if self.demo:
            i = int((time.time() - self.t0) // 4) % len(STATES)
            self.state, self.detail = STATES[i], "demo"
        else:
            try:
                s = jarvis_state.current()
                self.state, self.detail = s["state"], s.get("detail", "")
            except Exception as e:
                self.state, self.detail = "broken", "state read failed: %s" % e
        self.setToolTip("JARVIS - %s\n%s" % (self.state.upper(), self.detail))

    # ---------------------------------------------------------------- draw
    def apply_size(self):
        self.px = SIZES[self.size_key]
        pad = int(self.px * 0.35)
        self.pad = pad
        self.setFixedSize(self.px + 2 * pad, self.px + 2 * pad)

    def paintEvent(self, _):
        t = time.time() - self.t0
        st = self.state
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.Antialiasing)
        float_y = math.sin(t * 0.9) * self.px * 0.012
        rect = QRectF(self.pad, self.pad + float_y, self.px, self.px)
        k = self.px / 512.0

        body, glow, bloom = 1.0, 0.85, 0.55
        if st == "idle":
            br = 0.5 + 0.5 * math.sin(t * 2 * math.pi / 4)
            glow, bloom = 0.72 + 0.28 * br, 0.35 + 0.35 * br
        elif st == "thinking":
            glow, bloom = 0.65, 0.3
        elif st == "spawning":
            glow, bloom = 0.9, 0.75 + 0.2 * math.sin(t * 6)
        elif st == "hold":
            br = 0.5 + 0.5 * math.sin(t * 2 * math.pi / 2.2)
            glow, bloom = 0.8 + 0.2 * br, 0.45 + 0.3 * br
        elif st == "broken":
            if random.random() < 0.12:
                self.flick = random.uniform(0.05, 0.5)
            else:
                self.flick = min(1.0, self.flick + 0.15)
            body, glow, bloom = 0.7, 0.85 * self.flick, 0.5 * self.flick
        elif st == "approved":
            glow, bloom = 0.75, 0.55
        elif st == "asleep":
            body, glow, bloom = 0.55, 0.0, 0.0

        p.setOpacity(body)
        p.drawImage(rect, self.base)
        p.setCompositionMode(QPainter.CompositionMode_Plus)
        if bloom > 0:
            p.setOpacity(bloom)
            p.drawImage(rect, self.bloom[st])
        if glow > 0:
            p.setOpacity(glow)
            p.drawImage(rect, self.glow[st])

        if st == "thinking":                       # sweep across the visor
            x0, y0, x1, y1 = VISOR
            span = x1 - x0
            pos = x0 + ((t * 0.55) % 1.0) * (span + 90) - 60
            p.save()
            p.setClipRect(QRectF(rect.x() + pos * k, rect.y() + y0 * k, 70 * k, (y1 - y0) * k))
            p.setOpacity(1.0)
            p.drawImage(rect, self.white)
            p.drawImage(rect, self.white)
            p.restore()
        if st in ("spawning", "asleep"):          # core flare / faint ember
            p.setOpacity(1.0 if st == "spawning" else 0.25 + 0.15 * math.sin(t * 1.2))
            p.drawImage(rect, self.core[st])
        if st == "approved":                       # chevrons light bottom -> top
            step = int((t * 3.2) % 5)
            for i, (y0, y1) in enumerate(CHEV_ROWS):
                if i < step:
                    p.save()
                    p.setClipRect(QRectF(rect.x(), rect.y() + y0 * k, rect.width(), (y1 - y0) * k))
                    p.setOpacity(1.0)
                    p.drawImage(rect, self.glow["approved"])
                    p.drawImage(rect, self.glow["approved"])
                    p.restore()
        p.setCompositionMode(QPainter.CompositionMode_SourceOver)

        if st == "spawning":                       # four satellites
            cx, cy = rect.center().x(), rect.center().y()
            for i in range(4):
                a = t * 1.3 + i * math.pi / 2
                x = cx + math.cos(a) * self.px * 0.62
                y = cy + math.sin(a) * self.px * 0.22
                r = self.px * (0.035 + 0.01 * math.sin(a))
                g = QRadialGradient(QPointF(x, y), r * 3)
                g.setColorAt(0, QColor(230, 245, 255, 255))
                g.setColorAt(0.3, QColor(160, 210, 255, 160))
                g.setColorAt(1, QColor(120, 180, 255, 0))
                p.setOpacity(1.0)
                p.setPen(Qt.NoPen)
                p.setBrush(g)
                p.drawEllipse(QPointF(x, y), r * 3, r * 3)
        p.end()

    # ---------------------------------------------------------------- input
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None
        self.save_prefs()

    def mouseDoubleClickEvent(self, e):
        keys = list(SIZES)
        self.size_key = keys[(keys.index(self.size_key) + 1) % len(keys)]
        self.apply_size()
        self.save_prefs()

    def contextMenuEvent(self, e):
        m = QMenu(self)
        m.addSection("JARVIS - %s" % self.state.upper())
        for k in SIZES:
            a = QAction("Size %s" % k, m, checkable=True, checked=(k == self.size_key))
            a.triggered.connect(lambda _=False, k=k: self.set_size(k))
            m.addAction(a)
        d = QAction("Demo all states", m, checkable=True, checked=self.demo)
        d.triggered.connect(self.toggle_demo)
        m.addAction(d)
        m.addSeparator()
        m.addAction("Quit JARVIS pet", QApplication.quit)
        m.exec(e.globalPos())

    def set_size(self, k):
        self.size_key = k
        self.apply_size()
        self.save_prefs()

    def toggle_demo(self):
        self.demo = not self.demo
        self.t0 = time.time()
        self.read_state()

    # ---------------------------------------------------------------- prefs
    def load_prefs(self):
        try:
            return json.load(open(PREFS))
        except Exception:
            return {}

    def save_prefs(self):
        try:
            os.makedirs(os.path.dirname(PREFS), exist_ok=True)
            json.dump({"size": self.size_key, "x": self.x(), "y": self.y()}, open(PREFS, "w"))
        except Exception:
            pass


if __name__ == "__main__":
    app = QApplication(sys.argv)
    pet = Pet()
    if "--demo" in sys.argv:
        pet.toggle_demo()
    pet.show()
    sys.exit(app.exec())
