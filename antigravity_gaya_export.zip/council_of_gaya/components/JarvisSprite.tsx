"use client";

import { useEffect, useState } from "react";

// The Command Core — JARVIS's sprite. Same art + states as the desktop pet
// (Desktop\JARVIS\sprite). The white light layer is recoloured per state
// with a CSS mask, so one image covers every state.

type State = "idle" | "thinking" | "spawning" | "hold" | "broken" | "approved" | "asleep";

const COLOR: Record<State, string> = {
  idle: "#D4AF37",
  thinking: "#FFD73C",
  spawning: "#FFE066",
  hold: "#FFAA00",
  broken: "#FF3B3B",
  approved: "#2FD36F",
  asleep: "#7A7067",
};

export function JarvisSprite({ size = 30, showLabel = true }: { size?: number; showLabel?: boolean }) {
  const [s, setS] = useState<{ state: State; detail: string; armed: string }>({
    state: "idle",
    detail: "",
    armed: "?",
  });

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await fetch("/api/jarvis-state", { cache: "no-store" });
        const j = await r.json();
        if (alive && j.state) setS(j);
      } catch {}
    };
    tick();
    const id = setInterval(tick, 1500);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  const c = COLOR[s.state];
  const mask = (img: string): React.CSSProperties => ({
    position: "absolute",
    inset: 0,
    background: c,
    WebkitMaskImage: `url(/jarvis/${img})`,
    maskImage: `url(/jarvis/${img})`,
    WebkitMaskSize: "100% 100%",
    maskSize: "100% 100%",
  });

  return (
    <div className="flex items-center gap-2" title={`GAYA CORE — ${s.state.toUpperCase()}\n${s.detail}`}>
      <div className={`jarvis-core jarvis-${s.state}`} style={{ width: size, height: size, position: "relative" }}>
        <img src="/jarvis/base.png" alt="Mini Gaya" className="jarvis-base" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} />
        <div className="jarvis-bloom" style={{ ...mask("bloom.png"), mixBlendMode: "screen" }} />
        <div className="jarvis-glow" style={{ ...mask("glow.png"), mixBlendMode: "screen" }} />
        {s.state === "thinking" && <div className="jarvis-sweep" style={{ ...mask("glow.png"), background: undefined }} />}
        {s.state === "spawning" &&
          [0, 1, 2, 3].map((i) => (
            <span key={i} className="jarvis-sat" style={{ animationDelay: `${-i * 0.6}s` }} />
          ))}
      </div>
      {showLabel && (
        <span className="font-mono text-[10px] uppercase tracking-[0.16em]" style={{ color: s.state === "idle" || s.state === "asleep" ? undefined : c }}>
          <span className="text-os-accent font-bold">GAYA</span>
          <span className="text-os-dim"> · </span>
          <span className={s.state === "idle" || s.state === "asleep" ? "text-os-muted" : ""}>{s.state}</span>
        </span>
      )}
    </div>
  );
}
