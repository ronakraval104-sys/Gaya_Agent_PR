"""J's voice: Kokoro-82M `bm_george` with the film treatment, cached, streamed sentence by sentence.

    say("Good morning, Boss.")            queue it (after whatever is playing)
    say("Boss, ...", interrupt=True)       drop the queue and say this now
    stop()                                 silence
All local. Model files in ~/.jarvis/voice/models, cache in ~/.jarvis/voice/cache.
"""
import glob
import hashlib
import os
import queue
import re
import site
import threading
import time

import numpy as np

HOME = os.path.expanduser("~")
VOICE_DIR = os.path.join(HOME, ".jarvis", "voice")
MODELS = os.path.join(VOICE_DIR, "models")
CACHE = os.path.join(VOICE_DIR, "cache")
VOICE, SPEED, LANG = "bm_george", 0.92, "en-gb"
WARM = ["Voice is online, Boss. Hold right control and talk.", "Allow, or deny?", "Done.", "Sent.",
        "On it.", "I didn't catch that, Boss.", "Opening the deck.", "Muted.", "Voice off.",
        "Preparing for work, Boss.", "Allowed.", "Denied.", "Handed back to Claude Code."]


def _nvidia_dlls():
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        for d in glob.glob(os.path.join(sp, "nvidia", "*", "bin")):
            try:
                os.add_dll_directory(d)
                os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
            except OSError:
                pass


def film(x, sr):
    """The JARVIS treatment (light): a shade lower, intercom polish, a tiny room."""
    import jarvis_fx as fx
    x = x.astype(np.float64)
    x = x / (np.abs(x).max() + 1e-9) * 0.8
    x = fx.pitch(x, sr, -0.35)
    x = fx.eq(x, sr, hp=130.0, lp=8500.0, presence_db=2.5)
    x = fx.room(x, sr, 110, 0.07)
    x = fx.compress(x, 1.15)
    return (x / (np.abs(x).max() + 1e-9) * 0.9).astype(np.float32)


def sentences(text):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [p.strip() for p in parts if p.strip()]


class Speaker:
    def __init__(self, on_state=None):
        self.q = queue.Queue()
        self.on_state = on_state or (lambda s: None)
        self.muted = False
        self.ready = False
        self.gen = 0                        # bumps on interrupt: stale items are skipped
        self._k = None
        self._sr = 24000
        os.makedirs(CACHE, exist_ok=True)
        threading.Thread(target=self._worker, daemon=True).start()

    # ---------------------------------------------------------------- public
    def say(self, text, interrupt=False):
        if not text or self.muted:
            return
        if interrupt:
            self.stop()
        g = self.gen
        for s in sentences(text):
            self.q.put((g, s))

    def stop(self):
        self.gen += 1
        try:
            while True:
                self.q.get_nowait()
        except queue.Empty:
            pass
        if getattr(self, "_engine_type", None) == "kokoro":
            try:
                import sounddevice as sd
                sd.stop()
            except Exception:
                pass
        elif getattr(self, "_engine_type", None) == "pyttsx3":
            try:
                self._pyttsx3.stop()
            except Exception:
                pass

    # ---------------------------------------------------------------- engine
    def _load(self):
        # 1. Try Kokoro ONNX if available
        try:
            if os.path.exists(os.path.join(MODELS, "kokoro-v1.0.onnx")):
                import sys
                sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
                from kokoro_onnx import Kokoro
                self._k = Kokoro(os.path.join(MODELS, "kokoro-v1.0.onnx"), os.path.join(MODELS, "voices-v1.0.bin"))
                self._engine_type = "kokoro"
                self.ready = True
                self.on_state("tts-ready:kokoro")
                for w in WARM:                       # pre-render the common lines in the background
                    try:
                        self._render(w)
                    except Exception:
                        pass
                return
        except Exception:
            pass

        # 2. Resilient Fallback: pyttsx3 (Microsoft Hazel / Zira / David)
        try:
            import pyttsx3
            engine = pyttsx3.init()
            for v in engine.getProperty("voices"):
                v_name = v.name.lower()
                if "hazel" in v_name or "zira" in v_name:
                    engine.setProperty("voice", v.id)
                    break
            engine.setProperty("rate", 175)
            self._pyttsx3 = engine
            self._engine_type = "pyttsx3"
            self.ready = True
            self.on_state("tts-ready:pyttsx3")
            return
        except Exception as e:
            self.on_state("tts-error: %s" % e)

    def _render(self, text):
        key = hashlib.sha1(("%s|%s|%s|%s" % (VOICE, SPEED, "film", text)).encode()).hexdigest()[:20]
        path = os.path.join(CACHE, key + ".npy")
        if os.path.exists(path):
            return np.load(path), self._sr
        audio, sr = self._k.create(text, voice=VOICE, speed=SPEED, lang=LANG)
        audio = film(audio, sr)
        self._sr = sr
        np.save(path, audio)
        return audio, sr

    def _worker(self):
        try:
            self._load()
        except Exception as e:
            self.on_state("tts-error: %s" % e)
            return

        if getattr(self, "_engine_type", None) == "kokoro":
            import sounddevice as sd
            while True:
                g, text = self.q.get()
                if g != self.gen:
                    continue
                try:
                    audio, sr = self._render(text)
                    if g != self.gen:
                        continue
                    self.on_state("speaking")
                    sd.play(audio, sr)
                    sd.wait()
                except Exception as e:
                    self.on_state("tts-error: %s" % e)
                finally:
                    if self.q.empty():
                        self.on_state("idle")
        elif getattr(self, "_engine_type", None) == "pyttsx3":
            while True:
                g, text = self.q.get()
                if g != self.gen:
                    continue
                try:
                    self.on_state("speaking")
                    self._pyttsx3.say(text)
                    self._pyttsx3.runAndWait()
                except Exception as e:
                    self.on_state("tts-error: %s" % e)
                finally:
                    if self.q.empty():
                        self.on_state("idle")


if __name__ == "__main__":
    import sys
    s = Speaker(print)
    while not s.ready:
        time.sleep(0.2)
    s.say(" ".join(sys.argv[1:]) or "Voice is online, Boss. Hold right control and talk.")
    time.sleep(1)
    while not s.q.empty():
        time.sleep(0.2)
    time.sleep(6)
