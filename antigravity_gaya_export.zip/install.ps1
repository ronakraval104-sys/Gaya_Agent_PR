# =====================================================================
# Gaya Agent + Fused Subagents + 76 Skills + Mini Gaya + Council Pack
# =====================================================================
param(
    [string]$TargetDir = "$HOME\.gemini\config",
    [switch]$WorkspaceMode,
    [switch]$Force
)

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   GAYA SUITE AUTO-INSTALLER FOR ANTIGRAVITY (v10 FUSED)" -ForegroundColor Yellow
Write-Host "   Commander - Philosopher - Poet - Evergrowth" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($WorkspaceMode) {
    $TargetDir = Join-Path (Get-Location) ".agents"
    Write-Host "[*] Target Mode: Workspace Project ($TargetDir)" -ForegroundColor Magenta
} else {
    Write-Host "[*] Target Mode: Global Antigravity Config ($TargetDir)" -ForegroundColor Magenta
}

$RulesDir  = Join-Path $TargetDir "rules"
$SkillsDir = Join-Path $TargetDir "skills"
$AgentsDir = Join-Path $TargetDir "agents"

New-Item -ItemType Directory -Force -Path $RulesDir  | Out-Null
New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null
New-Item -ItemType Directory -Force -Path $AgentsDir | Out-Null

# Copy Rules & Persona
Write-Host "[+] Installing Gaya Persona & Hardened QC Rules..." -ForegroundColor Green
Copy-Item -Path "$ScriptDir\config\rules\*" -Destination $RulesDir -Recurse -Force

# Copy Agents
Write-Host "[+] Installing Fused Agent Council (Gaya, LOGOS, Bob, Freya, Tvashtar)..." -ForegroundColor Green
Copy-Item -Path "$ScriptDir\config\agents\*" -Destination $AgentsDir -Recurse -Force

# Copy 76 Skills
Write-Host "[+] Installing 76 Skills..." -ForegroundColor Green
$SkillDirs = Get-ChildItem -Directory "$ScriptDir\config\skills"
foreach ($s in $SkillDirs) {
    Copy-Item -Path $s.FullName -Destination $SkillsDir -Recurse -Force
}
$InstalledCount = (Get-ChildItem -Directory $SkillsDir).Count
Write-Host "    -> Verified $InstalledCount skills active." -ForegroundColor DarkGreen

# Configure MCP
$McpSource = Join-Path $ScriptDir "config\mcp_config.json"
$McpTarget = Join-Path $TargetDir "mcp_config.json"
if (Test-Path $McpSource) {
    Write-Host "[+] Configuring MCP Servers (Chrome DevTools, Parallel Search, Canva)..." -ForegroundColor Green
    Copy-Item -Path $McpSource -Destination $McpTarget -Force
}

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   INSTALLATION COMPLETE (76 Skills + 5 Agents Active)" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "Rules:   $RulesDir"
Write-Host "Agents:  $AgentsDir"
Write-Host "Skills:  $SkillsDir"
Write-Host "MCP:     $McpTarget"
Write-Host ""
Write-Host "Launch Mini Gaya Desktop Companion:  .\mini_gaya\start_mini_gaya.bat" -ForegroundColor White
Write-Host "Launch Council of Gaya Dashboard:   .\council_of_gaya\start_council.bat" -ForegroundColor White
Write-Host ""
