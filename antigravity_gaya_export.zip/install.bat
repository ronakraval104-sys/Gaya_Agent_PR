@echo off
title Installing Gaya Agent Suite for Antigravity
echo ==========================================================
echo Launching Gaya Installer with PowerShell Bypass...
echo ==========================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
