"""Cut the full-body JARVIS out of Boss's character sheet and split it into
light layers, so the body glows in JARVIS's state colour like the head does.

    python prep_body.py [sheet.png]

Output: art/body/<view>_{base,glow,bloom}.png  (views: front, three_quarter, side, back)
Background removal: rembg (U2Net, local, runs offline after first model download).
"""
import os
import sys

from PIL import Image, ImageChops, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SHEET = os.path.join(HERE, "art", "concepts", "Futuristic Android Sentinel Character Sheet-2.png")
OUT = os.path.join(HERE, "art", "body")
VIEWS = ["front", "three_quarter", "side", "back"]
H = 512


def split_light(im):
    r, g, b, a = im.split()
    hsv = im.convert("RGB").convert("HSV")
    _, s, v = hsv.split()
    g_int = Image.eval(v, lambda x: 0 if x < 120 else min(255, int((x - 120) * 255 / 135)))
    low_sat = Image.eval(s, lambda x: 255 if x < 55 else max(0, 255 - (x - 55) * 4))
    glow_a = ImageChops.multiply(ImageChops.multiply(g_int, low_sat), a)
    dim = Image.eval(glow_a, lambda x: 255 - int(x * 0.8))
    base = Image.merge("RGBA", (*[ImageChops.multiply(c, dim) for c in (r, g, b)], a))
    white = Image.new("L", im.size, 255)
    glow = Image.merge("RGBA", (white, white, white, glow_a))
    bloom = Image.merge("RGBA", (white, white, white, glow_a.filter(ImageFilter.GaussianBlur(10))))
    return base, glow, bloom


def main():
    from rembg import remove
    src = sys.argv[1] if len(sys.argv) > 1 else SHEET
    sheet = Image.open(src).convert("RGBA")
    W = sheet.width
    # the four turnaround figures sit in fixed columns on the 1536-wide sheet
    # (the 3/4 coat touches the side view, so column-gap splitting merges them)
    cols = [(0.010, 0.257), (0.257, 0.483), (0.483, 0.626), (0.626, 0.845)]
    os.makedirs(OUT, exist_ok=True)
    for name, (a0, a1) in zip(VIEWS, cols):
        part = remove(sheet.crop((int(a0 * W), 0, int(a1 * W), sheet.height)))
        box = part.getchannel("A").point(lambda v: 255 if v > 40 else 0).getbbox()
        fig = part.crop(box)
        fig = fig.resize((max(1, round(fig.width * H / fig.height)), H), Image.LANCZOS)
        base, glow, bloom = split_light(fig)
        for kind, img in (("base", base), ("glow", glow), ("bloom", bloom), ("full", fig)):
            img.save(os.path.join(OUT, "%s_%s.png" % (name, kind)))
        print("%-14s %dx%d" % (name, fig.width, fig.height))


if __name__ == "__main__":
    main()
