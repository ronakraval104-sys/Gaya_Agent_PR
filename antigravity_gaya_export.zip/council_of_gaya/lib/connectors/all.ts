import fs from "node:fs/promises";
import { getPublicRepoStatus, type RepoStatus } from "./github";
import { pingSite, type SiteStatus } from "./site-ping";

/**
 * Unified connector orchestrator. Every dashboard chip fetches through here
 * so a single /api/connectors round-trip returns the whole grid.
 *
 * Arnie's 36 pass:
 *   1/2/3/13 → no secrets in code; Metricool + Vercel-token connectors
 *              read from process.env only, never file paths
 *   5/34    → all outbound URLs are pinned server-side (env-var defaults
 *              or hard-coded), not passed from the client
 *   12      → structured status objects, no stack traces leaked
 *   28      → callers cache per-connector (site-ping 60s, GH 45s)
 */

const KATVIZ_EMPIRE_REPO = "katviZ/katviz-empire";
const VR_SITE_URL   = process.env.VR_SITE_URL   ?? "https://visualrhyme.digital";
const KV_PAGES_URL  = process.env.KV_PAGES_URL  ?? "https://katviz.github.io/katviz-empire/";
const VR_PRICING_PATH = process.env.VR_PRICING_XLSX_PATH ?? "";

export interface ConfigurableStatus {
  status: "ok" | "warn" | "err" | "off" | "not_configured";
  hint?: string;                 // short label rendered next to count (e.g. "07 Sept" or "add TOKEN")
  count?: number;                // number rendered on the right of the chip
  latestSha?: string;
  error?: string;
  fetchedAt: number;
  meta?: Record<string, unknown>;
}

export interface AllConnectors {
  githubEmpire: RepoStatus;
  vrSite:      SiteStatus;
  kvPages:     SiteStatus;
  metricool:   ConfigurableStatus;
  vrPricing:   ConfigurableStatus;
  fetchedAt:   number;
}

export async function getAllConnectors(): Promise<AllConnectors> {
  const [githubEmpire, vrSite, kvPages, metricool, vrPricing] = await Promise.all([
    getPublicRepoStatus(KATVIZ_EMPIRE_REPO),
    pingSite(VR_SITE_URL, 5000),
    pingSite(KV_PAGES_URL, 5000),
    getMetricoolStatus(),
    getVrPricingStatus()
  ]);
  return { githubEmpire, vrSite, kvPages, metricool, vrPricing, fetchedAt: Date.now() };
}

// ─── Metricool ──────────────────────────────────────────────
// Real API needs a user token + brand id. If unset, chip stays honest as
// "not_configured" with a hint on which env var to add.

async function getMetricoolStatus(): Promise<ConfigurableStatus> {
  const token = process.env.METRICOOL_USER_TOKEN;
  const brand = process.env.METRICOOL_BLOG_ID;
  if (!token || !brand) {
    return {
      status: "not_configured",
      hint: "set METRICOOL_USER_TOKEN + METRICOOL_BLOG_ID",
      fetchedAt: Date.now()
    };
  }
  // Real fetch stub — replace with actual Metricool API call when ready.
  // For now, return warn to indicate "token present, live fetch pending impl".
  return {
    status: "warn",
    hint: "token present · fetch impl pending",
    fetchedAt: Date.now()
  };
}

// ─── VR Pricing Sheet ────────────────────────────────────────
// Reads the xlsx path from env, reports file size (KB) + last-modified date.
// No sheet parsing yet — file stat only. Follow-up: parse SKU count via
// SheetJS if Katviz wants row counts.

async function getVrPricingStatus(): Promise<ConfigurableStatus> {
  if (!VR_PRICING_PATH) {
    return {
      status: "not_configured",
      hint: "set VR_PRICING_XLSX_PATH",
      fetchedAt: Date.now()
    };
  }
  try {
    const stat = await fs.stat(VR_PRICING_PATH);
    if (!stat.isFile()) {
      return {
        status: "err",
        hint: "path not a file",
        error: `not-a-file: ${VR_PRICING_PATH}`,
        fetchedAt: Date.now()
      };
    }
    const kb = Math.max(1, Math.round(stat.size / 1024));
    const mod = new Date(stat.mtimeMs).toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
    return {
      status: "ok",
      count: kb,
      hint: `mod ${mod}`,
      meta: { path: VR_PRICING_PATH, bytes: stat.size, mtimeMs: stat.mtimeMs },
      fetchedAt: Date.now()
    };
  } catch (err) {
    const msg = (err as NodeJS.ErrnoException).code === "ENOENT"
      ? "file not found"
      : ((err as Error).message ?? "stat-failed");
    return { status: "err", hint: msg, error: msg, fetchedAt: Date.now() };
  }
}
